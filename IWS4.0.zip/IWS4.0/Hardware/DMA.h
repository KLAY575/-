#ifndef __DMA_H
#define __DMA_H

void Dma_Init(uint32_t AddrA,uint32_t AddrB,uint16_t Size );
void DMA_Enable(void);

#endif
