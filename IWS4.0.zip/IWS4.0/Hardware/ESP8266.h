#ifndef __ESP8266_H
#define __ESP8266_H

void WIFI_Connect(void);
void Data_UP(void);

#endif
