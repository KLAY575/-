#ifndef __KEY_H
#define __KEY_H

void KEY_Init(void);
uint8_t Key_GetNum(void);
extern	uint8_t KeyNum;
#endif

