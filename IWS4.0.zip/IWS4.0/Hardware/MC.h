#ifndef __MC_H
#define __MC_H

void MC_Start(uint8_t MC );
extern uint8_t AC,MC;

#endif

