#ifndef __Motor_H
#define __Motor_H
void PWM_Init(void);
void Motor_Stop(void);
void Motor_Start(uint8_t setnum);
#endif
